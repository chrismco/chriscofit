=== Publish View ===
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VL5VBHN57FVS2
Contributors:launchinteractive
Tags: save, view, publish, update
Requires at least: 3.6.1
Stable tag: trunk
Tested up to: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a button so you can Publish and View Pages, Posts etc. in one step.

== Installation ==

1. Upload the `publish-view` folder to the `/wp-content/plugins/` directory or upload the zip within WordPress
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 1.3 =
* Prefix functions to avoid conflicts

= 1.2 =
* Hide button for ACF
* Fix position for Woocommerce
* Include fonts for old WP rather than linking to FontAwesome

= 1.1 =
* Added Support for WP 3.6+

= 1.0 =
* Initial Release.