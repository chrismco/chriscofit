=== WP Login Security and History ===
Contributors: fakhris
Donate link: http://www.clogica.com/donations.htm
Tags: Login,Security,History,Save
Requires at least: 3.0.1
Tested up to: 4.0.1
Stable tag: trunk

By this smart plugin you can protect your login page from Brute-force attacks also you can track login history

== Description ==
By this smart plugin you can protect your login page from Brute-force attacks also you can track login history.
Features:<ul>
<li>Captcha on the admin login page to protect against auto-hacking.</li>
<li>You can set the number of failed logins to show Captcha or showing it always.</li>
<li>Login Blocker option to block the login processe for a period of time after specific number of failed logins.</li>
<li>Login history to show all login processes in details.</li>
</ul>

You can see more about this plugin at <a target="_blank" href="http://www.clogica.com/wordpress-login-security-and-history-wordpress-plugin.htm">
WP Login Security and History WordPress Plugin</a>

== Installation ==
<ul>
<li>Go to the wordpress control panel and go to "Plugins" menu and press the button "Add New".</li>
<li>Go to the tab "Upload" and choose the file "wp-login-security-and-history.zip", click the button "Upload" to get the file uploaded.</li>
<li>Lockup the plugin, and click "Activate" to get it active.</li>
<li>Go to the Options page and configure the plugin.</li>
</ul>

<p>view this posts if you want more details about installing plugins: <a href="http://www.wpfasthelp.com/how-to-install-wordpress-plugins.htm">
http://www.wpfasthelp.com/how-to-install-wordpress-plugins.htm</a></p>

== Screenshots ==
1. Login history to show all login processes in details

2. Login Security options

